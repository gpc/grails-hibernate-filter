package org.grails.plugin.hibernate.filter

class HibernateFilterException extends Exception {

    public HibernateFilterException(String message) {
        super(message)
    }
}